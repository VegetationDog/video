import numpy as np
import cv2 as cv
from PIL import Image
import os

from numba import jit

Panel_Height = 1404
Panel_Width = 1872
Default_Image_Cfg = (Panel_Height, Panel_Width)
WHITE = 255
BLACK = 0


def classifyDiffLevel(diff_mat, lv_num):
    itvl = int(255 / lv_num)
    lvs = list(range(0, 510, itvl))
    # print(diff_mat)
    tmp_mat = np.copy(diff_mat).astype('int16') + 255
    # print(tmp_mat)
    new_mat = np.zeros_like(diff_mat).astype('int16')
    mats = {}
    for lv in lvs[::-1]:
        if lv == 0:
            continue
        tmp = (tmp_mat / lv).astype('int16')
        tmp_mat = tmp_mat - tmp * tmp_mat
        idx = lvs.index(lv) + 1 - lv_num
        new_mat = tmp * idx
        mats[idx] = new_mat
        pass
    return mats


def threshold(img, threshold, val, mode=0):
    h, w = img.shape
    new_img = np.zeros_like(img)
    for y in range(h):
        for x in range(w):
            if (mode == 0):  # new_img[y,x] = img[y,x]>threshold ? img[y,x]:val
                new_img[y, x] = img[y, x] if (img[y, x] > threshold) else val
            if (mode == 1):
                new_img[y, x] = img[y, x] + val if (img[y, x] > threshold) else 0
            if (mode == 2):
                new_img[y, x] = img[y, x] - val if (img[y, x] > threshold) else 0
            if (mode == 3):
                new_img[y, x] = val if (img[y, x] > threshold) else 0
            if (mode == 4):
                new_img[y, x] = val if (img[y, x] > threshold) else img[y, x]
            if (mode == 5):
                new_img[y, x] = img[y, x] + val if (img[y, x] > threshold) else img[y, x]
    return new_img


def pil_to_np(pilimage):
    return np.array(pilimage) / 255


def np_to_pil(image):
    return Image.fromarray((image * 255).astype('uint8'))


def saveBmp(path, img, bit_num=1):
    if bit_num == 1:
        _, img = cv.threshold(img, 127, 255, cv.THRESH_BINARY)
        cv.imwrite('tmp.png', img, [cv.IMWRITE_PNG_BILEVEL, 1])
        img2 = Image.open('tmp.png')
        img2.save(path)
        os.remove('tmp.png')
    else:
        cv.imwrite(path, img)


def showCv2Img(img):
    Image.fromarray(img).show()

# @jit(nopython=True)
def getAvgWin(img,x_step = 6,y_step = 6):
    mImg = np.copy(img)
    h, w = mImg.shape
    # print(h,w)
    img3 = createEmptyGrayScaleImage((int(h/y_step), int(w/x_step)),gray=0)
    acc = np.array([0])
    # plt.figure().set_size_inches(60, 80)
    for y in range(0, h, y_step):
        for x in range(0, w, x_step):
            avg = cv.mean(mImg[y:y + y_step, x:x+x_step])
            mImg[y:y + y_step, x:x+x_step] = avg[0]
            img3[int(y/y_step),int(x/x_step)] = avg[0]
        pass
    return mImg, img3

# @jit(nopython=True)
def floyd_steinberg(image):
    # image: np.array of shape (height, width), dtype=float, 0.0-1.0
    # works in-place!
    h, w = image.shape
    for y in range(h):
        for x in range(w):
            old = image[y, x]
            new = np.round(old)
            # print(old)
            # print(new)
            image[y, x] = new
            error = old - new
            # precomputing the constants helps
            if x + 1 < w:
                image[y, x + 1] += error * 0.4375  # right, 7 / 16
            if (y + 1 < h) and (x + 1 < w):
                image[y + 1, x + 1] += error * 0.0625  # right, down, 1 / 16
            if y + 1 < h:
                image[y + 1, x] += error * 0.3125  # down, 5 / 16
            if (x - 1 >= 0) and (y + 1 < h):
                image[y + 1, x - 1] += error * 0.1875  # left, down, 3 / 16
    return image


def ditherImageToBW(src_path, dst_path):
    img_statue = Image.open(src_path).convert('L')
    img_statue_array = pil_to_np(img_statue)
    img = img_statue_array
    floyd_steinberg(img_statue_array)
    new_img = np_to_pil(img_statue_array)
    new_img.convert('1').save(dst_path)


def getInversedImage(img):
    return ((np.ones(img.shape, dtype='uint8') * 255) - img)  # mask求反，用一个255的矩阵减mask


def saveImg(img, dst_path, bit_num='1'):
    new_img = np_to_pil(img)
    new_img.convert(bit_num).save(dst_path)


def getMaskOfImage(img, threshold=200, mask_val=255):
    _, mask = cv.threshold(img, threshold, mask_val, cv.THRESH_BINARY)
    # bg_mask = mask
    return mask


#
# file_in = "01.png"
# img2 = Image.open(file_in)
#
# file_out = "02.bmp"
# img2.save(file_out)

#

def createEmptyGrayScaleImage(H, W, gray=255):
    img = np.zeros((H, W), np.uint8)
    img.fill(gray)
    return img
    # cv2.imshow('img', img)
    # cv2.waitKey(0)


def createEmptyGrayScaleImage(shape=Default_Image_Cfg, gray=255):
    # img = np.zeros(shape, np.uint8)
    img = np.zeros(shape, np.int16)
    img.fill(gray)
    return img


def putText(img, text, x, y, scale, gray):
    cv.putText(img,  # img ptr
               text,  # Text to put
               (x, y),
               cv.FONT_HERSHEY_DUPLEX,
               scale, gray,
               thickness=int(scale * 1.6),
               lineType=4,
               bottomLeftOrigin=0)
    pass


def drawStrip(img, pt1, pt2, color=255, thickness=1):
    # cv.line(img, pt1, pt2, color, thickness=thickness)
    x1, y1 = pt1
    x2, y2 = pt2
    img[y1:y2, x1:x1 + thickness] = color

    pass


def drawStrips(img, x, y, len=500, N=1, thickness=1):
    for i in range(N):
        p_x = x + thickness * i * 2
        p_y = y
        drawStrip(img, (p_x, p_y), (p_x, p_y + 500), thickness=thickness)


def drawChunk(img, x, y, fg_color=255, bg_color=0, w=1):
    img[y:y + w, x:x + w] = fg_color  # left top
    img[y:y + w, x + w:x + 2 * w] = bg_color  # right top
    img[y + w:y + 2 * w, x + w:x + 2 * w] = fg_color  # right bottom
    img[y + w:y + 2 * w, x:x + w] = bg_color  # left bottom


def drawRect(img, x, y, h, w, color=0):
    img[y:y + h, x:x + w] = color  # left top


def drawHalfRects(img, x, y, h, w, left_color=255, right_color=0, N=50):
    h_step = w * 2
    v_step = h * 2
    x_N = int(h / w * N);
    for i in range(y, y + N * v_step + 1, v_step):
        for j in range(x, x + x_N * h_step + 1, h_step):
            img[i:i + h, j:j + w] = left_color
            img[i:i + h, j + w:j + 2 * w] = right_color
            img[i + h:i + 2 * h, j:j + w] = right_color
            img[i + h:i + 2 * h, j + w:j + 2 * w] = left_color
    pass


def drawChunks(img, x, y, fg_color=0, bg_color=255, w=1, N=50):
    for i in range(x, x + 2 * w * (N - 1) + 1, 2 * w):
        for j in range(y, y + 2 * w * (N - 1) + 1, 2 * w):
            drawChunk(img, i, j, fg_color, bg_color, w)


def saveAsGrayScaleImage(path, img):
    newimg = Image.fromarray(img)
    newimg.convert('L').save(path)


def saveAsBlackWhiteImage(path, img):
    newimg = Image.fromarray(img)
    newimg.convert('1').save(path)


def drawHorizontalGradientStrip(img, x, y, h, w, from_color, to_color, step=1, line=False):
    end_x = x + w
    end_y = y + h
    step = abs(step)
    color_step = step if to_color > from_color else -step
    x_step = step
    x_step = int(w / abs(from_color - to_color))
    current_color = from_color
    for i in range(x, end_x, x_step):
        img[y:end_y, i:i + x_step] = current_color
        current_color = current_color + color_step
        if line:
            p_x = i
            p_y = y
            h = int((end_y - y) / 2)
            img[y:y + h, i] = 255
        pass


def putText(img, text, x, y, scale, gray):
    cv.putText(img,  # img ptr
               text,  # Text to put
               (x, y),
               cv.FONT_HERSHEY_DUPLEX,
               scale, gray,
               thickness=int(scale * 1.6),
               lineType=4,
               bottomLeftOrigin=0)
    pass
