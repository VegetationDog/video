import numpy as np
import cv2 as cv
from PIL import Image
import os

from numba import jit

import epd_utils as epd


@jit(nopython=True)
def isInImg(img, x, y):
    h, w = img.shape
    return (x in range(w)) and (y in range(h))


@jit(nopython=True)
def checkAdjacent(mA, mB, mD, x, y):
    cnt = 0
    if isInImg(mA, x, y):
        d = mD[y, x]
        a = mA[y, x]
        b = mB[y, x]
        cnt = 1 if ((d == 0) and (a == 0)) else 0
    return cnt


@jit(nopython=True)
def getWhiteEdgeCnt(imgA, imgB):
    A = imgA / 255
    B = imgB / 255
    D = B - A
    WhiteEdge = np.zeros_like(D)
    WE_CNT_LUT = {}
    WE_POS_LUT = {}
    # posOf4 = []
    # posOf3 = []
    # posOf2 = []
    # posOf1 = []
    h, w = D.shape
    for y in range(h):
        for x in range(w):
            px = D[y, x]
            if px == -1:
                cnt = 0
                pos = 0;
                tmp = checkAdjacent(A, B, D, x - 1, y)  # left
                cnt = cnt + tmp
                pos = 8 + pos if tmp > 0 else pos
                tmp = checkAdjacent(A, B, D, x, y - 1)  # up
                cnt = cnt + tmp
                pos = 4 if tmp > 0 else pos
                tmp = checkAdjacent(A, B, D, x + 1, y)  # right
                cnt = cnt + tmp
                pos = 2 if tmp > 0 else pos
                tmp = checkAdjacent(A, B, D, x, y + 1)  # down
                cnt = cnt + tmp
                pos = 1 if tmp > 0 else pos
                WhiteEdge[y, x] = cnt
                if cnt > 0:
                    WE_CNT_LUT[(x, y)] = cnt
                    WE_POS_LUT[(x, y)] = pos
                pass
            pass
    return WE_CNT_LUT, WE_POS_LUT, WhiteEdge


@jit(nopython=True)
def getWhiteEdgeCnt2(imgA, imgB):
    A = imgA / 255
    B = imgB / 255
    D = B - A
    WhiteEdge = np.zeros_like(D)
    WE_CNT_LUT = {}
    WE_POS_LUT = {}
    h, w = D.shape
    for y in range(h):
        for x in range(w):
            px = D[y, x]
            if px == -1:
                cnt = 0
                pos = 0;
                tmp = checkAdjacent(A, B, D, x + 1, y)  # right
                cnt = cnt + tmp
                pos = pos | 1 if tmp > 0 else pos
                tmp = checkAdjacent(A, B, D, x, y + 1)  # down
                cnt = cnt + tmp
                pos = pos | 2 if tmp > 0 else pos
                WhiteEdge[y, x] = cnt
                if cnt > 0:
                    WE_CNT_LUT[(x, y)] = cnt
                    WE_POS_LUT[(x, y)] = pos
                pass
            pass
    return WE_CNT_LUT, WE_POS_LUT, WhiteEdge

# # shape = epd.Default_Image_Cfg
# shape = (5, 5)
# img_B = epd.createEmptyGrayScaleImage(shape, gray=0)
#
# img_A = epd.createEmptyGrayScaleImage(shape=shape)
#
# # epd.drawChunks(img_A,0,1,w=2,N=1)
# # epd.drawChunks(img_B,0,0,w=1,N=2)
# # epd.drawChunks(img_A,0,10,w=2,N=100)
# # epd.drawChunks(img_B,0,0,w=1,N=200)
#
# img_A[:, 2] = 0
# img_A[2, 1] = 0
#
# epd.saveAsBlackWhiteImage('img_A.bmp', img_A)
# epd.saveAsBlackWhiteImage('img_B.bmp', img_B)
#
# # epd.drawChunks(img_B,103,100,w=2,N=2)
#
# we_cnt_lut, we_pos_lut, we_mat = getWhiteEdgeCnt(img_A, img_B)

# print(we_pos_lut)
# A = img_A / 255
# B = img_B / 255
# D = B - A
# print(A)
# print(D)
# print(we_mat)
