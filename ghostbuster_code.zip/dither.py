import numpy as np
import cv2 as cv
from PIL import Image
import os

from numba import jit

import epd_utils as epd


@jit(nopython=True)
def floyd_steinberg(image):
    # image: np.array of shape (height, width), dtype=float, 0.0-1.0
    # works in-place!
    h, w = image.shape
    for y in range(h):
        for x in range(w):
            old = image[y, x]
            new = np.round(old)
            # print(old)
            # print(new)
            image[y, x] = new
            error = old - new
            # precomputing the constants helps
            if x + 1 < w:
                image[y, x + 1] += error * 0.4375  # right, 7 / 16
            if (y + 1 < h) and (x + 1 < w):
                image[y + 1, x + 1] += error * 0.0625  # right, down, 1 / 16
            if y + 1 < h:
                image[y + 1, x] += error * 0.3125  # down, 5 / 16
            if (x - 1 >= 0) and (y + 1 < h):
                image[y + 1, x - 1] += error * 0.1875  # left, down, 3 / 16
    return image

@jit(nopython=True)
def stucki(image):
    h, w = image.shape
    for y in range(h):
        for x in range(w):
            old = image[y, x]
            new = np.round(old)
            image[y, x] = new
            error = old - new
            # precomputing the constants helps
            u8 = 8 / 42
            u7 = 7/42
            u5 = 5/42
            u4 = 4/42
            u2 = 2/42
            u1 = 1/42
            if x + 1 < w:
                image[y, x + 1] += error * u7
            if x + 2 < w:
                image[y, x + 2] += error * u5
            if y + 1 < h:
                image[y + 1, x] += error * u8
            if y + 2 < h:
                image[y + 2, x] += error * u4
            if (y + 1 < h) and (x + 1 < w):
                image[y + 1, x + 1] += error * u4
            if (x - 1 >= 0) and (y + 1 < h):
                image[y + 1, x - 1] += error * u4
            if (y + 1 < h) and (x + 2 < w):
                image[y + 1, x + 2] += error * u2
            if (y + 2 < h) and (x + 1 < w):
                image[y + 2, x + 1] += error * u2
            if (x - 1 >= 0) and (y + 2 < h):
                image[y + 2, x - 1] += error * u2
            if (x - 2 >= 0) and (y + 1 < h):
                image[y + 1, x - 2] += error * u2
            if (y + 2 < h) and (x + 2 < w):
                image[y + 2, x + 2] += error * u1
            if (x - 2 >= 0) and (y + 2 < h):
                image[y + 2, x - 2] += error * u1
    return image

@jit(nopython=True)
def jarvis(image):
    h, w = image.shape
    for y in range(h):
        for x in range(w):
            old = image[y, x]
            new = np.round(old)
            image[y, x] = new
            error = old - new
            # precomputing the constants helps
            u7 = 7/48
            u5 = 5/48
            u3 = 3/48
            u1 = 1/48
            if x + 1 < w:
                image[y, x + 1] += error * u7
            if x + 2 < w:
                image[y, x + 2] += error * u5
            if y + 1 < h:
                image[y + 1, x] += error * u7
            if y + 2 < h:
                image[y + 2, x] += error * u5
            if (y + 1 < h) and (x + 1 < w):
                image[y + 1, x + 1] += error * u5
            if (x - 1 >= 0) and (y + 1 < h):
                image[y + 1, x - 1] += error * u5
            if (y + 1 < h) and (x + 2 < w):
                image[y + 1, x + 2] += error * u3
            if (y + 2 < h) and (x + 1 < w):
                image[y + 2, x + 1] += error * u3
            if (x - 1 >= 0) and (y + 2 < h):
                image[y + 2, x - 1] += error * u3
            if (x - 2 >= 0) and (y + 1 < h):
                image[y + 1, x - 2] += error * u3
            if (y + 2 < h) and (x + 2 < w):
                image[y + 2, x + 2] += error * u1
            if (x - 2 >= 0) and (y + 2 < h):
                image[y + 2, x - 2] += error * u1
    return image


@jit(nopython=True)
def diffuse_error(image):
    # image: np.array of shape (height, width), dtype=float, 0.0-1.0
    # works in-place!
    h, w = image.shape
    for y in range(h):
        for x in range(w):
            old = image[y, x]
            new = np.round(old)
            # print(old)
            # print(new)
            image[y, x] = new
            error = old - new
            # precomputing the constants helps
            # u1 = 0.4375
            # u2 = 0.0625
            # u3 = 0.3125
            # u4 = 0.1875
            u1 = 1/4
            u2 = 1/4
            u3 = 1/4
            u4 = 1/4
            if x + 1 < w:
                image[y, x + 1] += error * u1  # right, 7 / 16
            if (y + 1 < h) and (x + 1 < w):
                image[y + 1, x + 1] += error * u2  # right, down, 1 / 16
            if y + 1 < h:
                image[y + 1, x] += error * u3  # down, 5 / 16
            if (x - 1 >= 0) and (y + 1 < h):
                image[y + 1, x - 1] += error * u4  # left, down, 3 / 16
    return image


@jit(nopython=True)
def diffuse_error2(image):
    # image: np.array of shape (height, width), dtype=float, 0.0-1.0
    # works in-place!
    h, w = image.shape
    for y in range(h-1, -1, -1):
        for x in range(w):
            old = image[y, x]
            new = np.round(old)
            # print(old)
            # print(new)
            image[y, x] = new
            error = old - new
            # precomputing the constants helps
            # u1 = 0.4375
            # u2 = 0.0625
            # u3 = 0.3125
            # u4 = 0.1875
            u1 = 1/4
            u2 = 1/4
            u3 = 1/4
            u4 = 1/4
            if x + 1 < w:
                image[y, x + 1] += error * u1  # right, 7 / 16
            if (y -1 >= 0) and (x + 1 < w):
                image[y - 1, x + 1] += error * u2  # right, down, 1 / 16
            if y -1 >= 0:
                image[y - 1, x] += error * u3  # down, 5 / 16
            if (x - 1 >= 0) and (y -1 >= 0):
                image[y - 1, x - 1] += error * u4  # left, down, 3 / 16
    return image